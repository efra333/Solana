package com.example.solana
import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

class Types(var mList: List<Tipos>) :
    RecyclerView.Adapter<Types.LanguageViewHolder>() {
    inner class LanguageViewHolder(itemView : View): RecyclerView.ViewHolder(itemView){
    val logo:ImageView=itemView.findViewById(R.id.logoIv)
        val titletv: TextView = itemView.findViewById(R.id.titleTv)

    }
fun setFiltered(mList: List<Tipos>){
    this.mList=mList
    notifyDataSetChanged()
}
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LanguageViewHolder {
      val view=LayoutInflater.from(parent.context).inflate(R.layout.each_item,parent,false)
        return LanguageViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    override fun onBindViewHolder(holder: LanguageViewHolder, position: Int) {
       holder.logo.setImageResource(mList[position].logo)
        holder.titletv.text = mList[position].title

    }
}