package com.example.solana

data class Tipos(val title:String, val logo: Int)

